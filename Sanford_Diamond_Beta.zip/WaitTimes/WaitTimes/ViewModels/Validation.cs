﻿using System;
using System.Collections.Generic;
using System.IO;
using Xamarin.Forms;
namespace WaitTimes.ViewModels
{
    public class Validation
    {
        //validate field not empty
        public static void ValNotEmpty(string entry)
        {
            if (string.IsNullOrWhiteSpace(entry))
            {
                //display alert
            }
        }

        //validate not duplicate in list
        public static string ValNotDupe (List<string> list, string input)
        {
            if (list.Contains(input))
            {
                //display alert
            }
            return input;
        }

        //validate file exists
        public static string ValFileExists (string filename)
        {
            if (!File.Exists(filename))
            {
                //display alert
            }
            return filename;
        }

        //validate password
        public static string ValPassword(string password,string confPassword)
        {
            if(password != confPassword)
            {
                //display alert
            }

            return password;
        }

    }
}
