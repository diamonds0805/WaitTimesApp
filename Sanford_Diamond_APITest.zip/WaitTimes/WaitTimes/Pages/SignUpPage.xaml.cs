﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SignUpPage : ContentPage
    {
        public SignUpPage()
        {
            InitializeComponent();
        }
    }
}
