﻿using System;
using System.Collections.Generic;

namespace WaitTimes.ViewModels
{
    public class UserProfileData
    {
        //create properties for user profile
        public string FileName { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Zipcode { get; set; }
        public List<string> FavoriteRestaurants { get; set; }

    }
}
