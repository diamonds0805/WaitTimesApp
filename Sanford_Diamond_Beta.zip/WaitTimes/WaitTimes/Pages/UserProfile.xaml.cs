﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class UserProfile : ContentPage
    {

       
        ObservableCollection<RestaurantData> restaurants;
        
        UserProfileData user = new UserProfileData();

        private ToolbarItem signOut;

        private ToolbarItem deleteFavorite;
        public UserProfile()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            restaurants = new ObservableCollection<RestaurantData>();
           
            MessagingCenter.Subscribe<UserProfileData>(this, "ViewProfile", (sender) =>
            {
                user = sender;
                userNameLabel.Text = user.Firstname + " " + user.Lastname;
                if(user.FavoriteRestaurants.Count >= 0)
                {
                    foreach(RestaurantData favorite in user.FavoriteRestaurants)
                    {
                        if (!restaurants.Contains(favorite))
                        {
                            restaurants.Add(favorite);
                        }
                    }
                }
                
            });

            collectionView.SelectionMode = SelectionMode.Single;
            this.signOut = new ToolbarItem
            {
                Text = "Sign Out",
                
                Order = ToolbarItemOrder.Primary,
                Priority = 0,
            };
            ToolbarItems.Add(signOut);
            
            signOut.Clicked += SignOut_ClickedAsync;

            this.deleteFavorite = new ToolbarItem
            {
                Text = "Delete Favorite",
                Order = ToolbarItemOrder.Secondary,
                Priority = 1,
            };
            ToolbarItems.Add(deleteFavorite);
            deleteFavorite.Command = new Command((sender) =>
            {
                this.DeleteCommand();
            });

            collectionView.ItemsSource = restaurants;
            collectionView.BackgroundColor = Color.FromHex("#9AD4C9");
           
            collectionView.SelectionChanged += CollectionView_SelectionChanged;
            MessagingCenter.Send<UserProfileData>(user, "UserSearch");
        }

        private void CollectionView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            RestaurantData faveRestaurant = new RestaurantData();

                faveRestaurant = restaurants[restaurants.IndexOf((RestaurantData)collectionView.SelectedItem)];
            

                Navigation.PushModalAsync(new RestaurantDetails_FromProfile());
                MessagingCenter.Send<RestaurantData>(faveRestaurant, "SeeDetails_Profile");

                MessagingCenter.Send<UserProfileData>(user, "SeeDetails_User");
           
        }

        private async void SignOut_ClickedAsync(object sender, EventArgs e)
        {
           bool response = await DisplayAlert("Log Out", $"Are you sure you want to log out {user.Email}?", "Yes", "No");

            if (response)
            {
                if (user.FileName != null)
                {
                    using (StreamWriter writer = new StreamWriter(user.FileName))
                    {
                        writer.WriteLine(user.Firstname);
                        writer.WriteLine(user.Lastname);
                        writer.WriteLine(user.Email);
                        writer.WriteLine(user.Password);
                        foreach (RestaurantData restaurant in user.FavoriteRestaurants)
                        {
                            writer.WriteLine(restaurant.RestaurantName);
                            writer.WriteLine(restaurant.BusinessHours);
                        }

                    }

                    user = null;
                    await DisplayAlert("Success", "You have been logged out", "Ok");
                    string message = "user signed out";

                    await Navigation.PopToRootAsync();
                    MessagingCenter.Send<string>(message, "SignOut");
                }
            }
        }

        async void DeleteCommand()
        {
            int index = restaurants.IndexOf((RestaurantData)collectionView.SelectedItem);
            bool response = await DisplayAlert("Delete Favorite", "Delete this restaurant?", "Yes", "No");
            if (response)
            {
                if (index > -1)
                {
                    restaurants.RemoveAt(index);
                    user.FavoriteRestaurants.RemoveAt(index);
                }
            }
         
        }
    }
}
