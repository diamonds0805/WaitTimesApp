﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SignInPage : ContentPage
    {
        UserProfileData userProfile = new UserProfileData();

        public SignInPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            loginButton.Clicked += LoginButton_Clicked;
            signUpButton.Clicked += SignUpButton_Clicked;
        }

        private void SignUpButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new SignUpPage());
        }

        private void LoginButton_Clicked(object sender, EventArgs e)
        {
            
            string[] entriesArray = new string[] { emailEntry.Text, passwordEntry.Text };
            bool login = ValidateEntries(entriesArray);
            if (login)
            {
                var files = Directory.EnumerateFiles(App.FolderPath, "*.WaitTimes.txt");

                foreach (var filename in files)
                {
                    if (filename != null)
                    {
                        
                        userProfile.FileName = filename;
                        using (StreamReader reader = new StreamReader(filename))
                        {
                            
                            userProfile.Firstname = reader.ReadLine();
                            userProfile.Lastname = reader.ReadLine();
                            userProfile.Email = reader.ReadLine();
                            userProfile.Password = reader.ReadLine();
                            List<string> restaurantInfo = new List<string>();
                            string readString = reader.ReadToEnd();
                            //char[] limits = new char[] { '\r', '\n' };
                            if (!string.IsNullOrWhiteSpace(readString))
                            {
                                string[] readArr = readString.Split('\r', '\n');
                                foreach (string s in readArr)
                                {
                                    RestaurantData favorite = new RestaurantData();
                                    if (string.IsNullOrWhiteSpace(s))
                                    {
                                        favorite = null;
                                    }else if (s.Contains("Hours"))
                                    {
                                        favorite.BusinessHours = s;
                                    }
                                    else
                                    {
                                        favorite.RestaurantName = s;
                                    }
                                    userProfile.FavoriteRestaurants.Add(favorite);
                                }
                            }
                            else
                            {
                                userProfile.FavoriteRestaurants = new List<RestaurantData>();
                            }
                        }
                        
                    }
                }
                DisplayAlert("Success!", "You're logged in.", "Ok");
                Navigation.PushAsync(new MainPage());
                MessagingCenter.Send<UserProfileData>(userProfile, "ViewProfile");
            }
        }

        //validate entries
        private bool ValidateEntries(string[] entries)
        {
            bool valid = true;
            if (entries.Length >= 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    if (string.IsNullOrWhiteSpace(entries[i]))
                    {
                        DisplayAlert("Blank Entry!", "Please don't leave any fields blank", "Ok");
                        emailEntry.Text = null;
                        passwordEntry.Text = null;
                        valid = false;
                    }
                    else
                    {
                        var files = Directory.EnumerateFiles(App.FolderPath, "*.WaitTimes.txt");

                        foreach (var filename in files)
                        {
                            if (File.Exists(filename))
                            {
                                userProfile.FileName = filename;

                                using (StreamReader reader = new StreamReader(filename))
                                {
                                    
                                    userProfile.Firstname = reader.ReadLine();
                                    userProfile.Lastname = reader.ReadLine();
                                    userProfile.Email = reader.ReadLine();
                                    userProfile.Password = reader.ReadLine();
                                    
                                }
                                
                            }
                        }
                        if (entries[0].ToLower() != userProfile.Email.ToLower())
                        {
                            DisplayAlert("Email Not Found!", "Enter a new email address or sign up", "Try Again");
                            emailEntry.Text = null;
                            valid = false;
                        }
                        else if (entries[1] != userProfile.Password)
                        {
                            DisplayAlert("Password Incorrect!", "Password entered does not match our records", "Try again");
                            passwordEntry.Text = null;
                            valid = false;
                        }
                    }
                }
            }
            return valid;

        }
    }
}
