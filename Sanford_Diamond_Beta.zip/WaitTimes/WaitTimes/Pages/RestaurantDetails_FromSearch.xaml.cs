﻿using System;
using System.Collections.Generic;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class RestaurantDetails_FromSearch : ContentPage
    {
        RestaurantData restaurant;
        UserProfileData user;
        public RestaurantDetails_FromSearch()
        {
            InitializeComponent();
            //Initialize restaurantData
            restaurant = new RestaurantData();
            user = new UserProfileData();
            //subscribe to messagingCenter
            MessagingCenter.Subscribe<RestaurantData>(this, "SeeDetails_Search", (sender) =>
            {
                restaurant = sender;
                nameLabel.Text = restaurant.RestaurantName;
            });
            MessagingCenter.Subscribe<UserProfileData>(this, "SeeDetails_User", (sender) =>
            {
                user = sender;
                
            });
            
            closeButton.Clicked += CloseButton_Clicked;
            addToFavoritesButton.Clicked += AddToFavoritesButton_Clicked;
            hoursButton.Clicked += HoursButton_Clicked;
            
        }

        private void HoursButton_Clicked(object sender, EventArgs e)
        {
            detailsLabel.IsVisible = true;
            detailsFrame.IsVisible = true;
                if (string.IsNullOrWhiteSpace(restaurant.BusinessHours))
                {
                    DisplayAlert("No Hours", "Business Hours Not Found!", "Ok");
                }
                else
                {
                    detailsLabel.Text = restaurant.BusinessHours;
                }
           
        }

        private async void AddToFavoritesButton_Clicked(object sender, EventArgs e)
        {
            bool add = await DisplayAlert("Add To Favorites", "Are you sure you want to add this restaurant?", "Yes", "No");
            if (add)
            {
                if (user.FavoriteRestaurants != null)
                {
                    if (!user.FavoriteRestaurants.Contains(restaurant))
                    {
                        user.FavoriteRestaurants.Add(restaurant);
                        await DisplayAlert("Added!", $"{restaurant.RestaurantName} has been added to your favorites", "Ok");
                        await Navigation.PopModalAsync();
                        MessagingCenter.Send<UserProfileData>(user, "ViewProfile");

                    }
                    else
                    {
                        await DisplayAlert("Already Added", $"{restaurant.RestaurantName} is already on your favorites list", "Ok");
                        await Navigation.PopModalAsync();

                    }
                }
                else
                {
                    user.FavoriteRestaurants = new List<RestaurantData>();
                    user.FavoriteRestaurants.Add(restaurant);
                    await DisplayAlert("Added!", $"{restaurant.RestaurantName} has been added to your favorites", "Ok");
                    await Navigation.PopModalAsync();
                    MessagingCenter.Send<UserProfileData>(user, "ViewProfile");
                }
                    
                }
            }
        

        private void CloseButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            detailsFrame.IsVisible = false;
            detailsLabel.IsVisible = false;
        }
    }
}
