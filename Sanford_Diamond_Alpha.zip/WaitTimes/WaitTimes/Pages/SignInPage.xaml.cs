﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SignInPage : ContentPage
    {
        UserProfileData userProfile = new UserProfileData();

        public SignInPage()
        {
            InitializeComponent();
            loginButton.Clicked += LoginButton_Clicked;
        }

        private void LoginButton_Clicked(object sender, EventArgs e)
        {
            
            string[] entriesArray = new string[] { emailEntry.Text, passwordEntry.Text };
            bool login = ValidateEntries(entriesArray);
            if (login)
            {
                var files = Directory.EnumerateFiles(App.FolderPath, "*.WaitTimes.txt");

                foreach (var filename in files)
                {
                    if (filename != null)
                    {
                        using (StreamReader reader = new StreamReader(filename))
                        {
                            userProfile.FileName = filename;
                            userProfile.Firstname = reader.ReadLine();
                            userProfile.Lastname = reader.ReadLine();
                            userProfile.Email = reader.ReadLine();
                            userProfile.Password = reader.ReadLine();
                        }

                        MessagingCenter.Send<UserProfileData>(userProfile, "Login");
                    }
                }
                DisplayAlert("Success!", "You're logged in.", "Ok");
                Navigation.PushAsync(new NavigationPage(new MainPage()));
                if (userProfile.FavoriteRestaurants != null)
                {
                    MessagingCenter.Send<UserProfileData>(userProfile, "ViewFavorites");
                }
            }
        }

        //validate entries
        private bool ValidateEntries(string[] entries)
        {
            bool valid = true;
            if (entries.Length >= 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    if (string.IsNullOrWhiteSpace(entries[i]))
                    {
                        DisplayAlert("Blank Entry!", "Please don't leave any fields blank", "Ok");
                        emailEntry.Text = null;
                        passwordEntry.Text = null;
                        valid = false;
                    }
                    else
                    {
                        var files = Directory.EnumerateFiles(App.FolderPath, "*.WaitTimes.txt");

                        foreach (var filename in files)
                        {
                            if (File.Exists(filename))
                            {
                                using (StreamReader reader = new StreamReader(filename))
                                {
                                    userProfile.FileName = filename;
                                    userProfile.Firstname = reader.ReadLine();
                                    userProfile.Lastname = reader.ReadLine();
                                    userProfile.Email = reader.ReadLine();
                                    userProfile.Password = reader.ReadLine();
                                    
                                }
                                
                            }
                        }
                        if (entries[0].ToLower() != userProfile.Email.ToLower())
                        {
                            DisplayAlert("Email Not Found!", "Enter a new email address or sign up", "Try Again");
                            emailEntry.Text = null;
                            valid = false;
                        }
                        else if (entries[1] != userProfile.Password)
                        {
                            DisplayAlert("Password Incorrect!", "Password entered does not match our records", "Try again");
                            passwordEntry.Text = null;
                            valid = false;
                        }
                    }
                }
            }
            return valid;

        }
    }
}
