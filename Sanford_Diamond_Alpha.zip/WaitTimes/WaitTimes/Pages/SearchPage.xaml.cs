﻿using System;
using System.Collections.Generic;
using System.IO;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SearchPage : ContentPage
    {
        //create list for listview datatemplate
        List<RestaurantData> restaurants = new List<RestaurantData>();
        UserProfileData user = new UserProfileData();
        public SearchPage()
        {
            InitializeComponent();
            //set up dataTemplate
            DataTemplate restaurantData = new DataTemplate(typeof(ImageCell));
            restaurantData.SetBinding(ImageCell.ImageSourceProperty, new Binding("Logo"));
            restaurantData.SetBinding(ImageCell.TextProperty, new Binding("RestaurantName"));
            restaurantData.SetBinding(ImageCell.DetailProperty, new Binding("BusinessHours"));

            //set listview to dataTemplate
            searchListView.ItemTemplate = restaurantData;
            MessagingCenter.Subscribe<UserProfileData>(this, "UserSearch", (sender) =>
            {
                user = sender;
            });
            //create searchBar event
            searchBar.TextChanged += SearchBar_TextChanged;
            searchListView.ItemSelected += SearchListView_ItemSelected;
            
            
        }

        private void SearchListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if(e.SelectedItem != null)
            {


                Navigation.PushModalAsync(new NavigationPage(new RestaurantDetails_FromSearch()));
                MessagingCenter.Send<RestaurantData>((RestaurantData)e.SelectedItem, "SeeDetails_Search");

                MessagingCenter.Send<UserProfileData>(user, "SeeDetails_User");
            }
        }

        async void SearchBar_TextChanged(object sender, TextChangedEventArgs e)
        {
            //Validation.ValNotEmpty(searchBar.Text);
            //use try catch to search API
            if (!string.IsNullOrWhiteSpace(searchBar.Text))
            {
                //restaurants.Clear();
                try
                {
                    SearchBar searchBar = (SearchBar)sender;
                    APIDataManagement aPIData = new APIDataManagement();
                    restaurants = await aPIData.GetRestaurants(searchBar.Text);
                    searchListView.ItemsSource = restaurants;
                }
                catch
                {

                    searchBar.Text = null;
                    searchBar.Placeholder = "Enter Zipcode";
                    await DisplayAlert("No Restaurants Found!", "Try another zip code.", "Ok");
                }
            }

        }
    }
}
