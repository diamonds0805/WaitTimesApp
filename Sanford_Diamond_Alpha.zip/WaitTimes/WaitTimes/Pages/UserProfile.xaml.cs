﻿using System;
using System.Collections.Generic;

using System.Linq;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class UserProfile : ContentPage
    {

       
        RestaurantData restaurant;
        List<string> restaurantIDS = new List<string>();
        UserProfileData user = new UserProfileData();

        public UserProfile()
        {
            InitializeComponent();
            restaurant = new RestaurantData();
            DataTemplate template = new DataTemplate(typeof(TextCell));
            

            MessagingCenter.Subscribe<UserProfileData>(this, "ViewFavorites", (sender) =>
            {
                user = sender;
                userNameLabel.Text = user.Firstname + " " + user.Lastname;
            });
            MessagingCenter.Subscribe<RestaurantData>(this, "NewFavorite", (sender) =>
            {
                restaurant = sender;
            });
            template.SetBinding(TextCell.TextProperty, new Binding("RestaurantName"));
            template.SetBinding(TextCell.DetailProperty, new Binding("BusinessHours"));
            listView.ItemTemplate = template;
            MessagingCenter.Send<UserProfileData>(user, "UserSearch");
        }
    }
}
