﻿using System;
using System.Collections.Generic;
using System.IO;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SignUpPage : ContentPage
    {
        UserProfileData newUser = new UserProfileData();
        public SignUpPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            submitButton.Clicked += SubmitButton_Clicked;
            signInButton.Clicked += SignInButton_Clicked;
            MessagingCenter.Subscribe<string>(this, "SignOut", (sender) =>
              {

                  newUser = null;
                  firstNameEntry.Text = null;
                  lastNameEntry.Text = null;
                  emailEntry.Text = null;
                  passwordEntry.Text = null;
                  confirmPasswordEntry.Text = null;
              });
        }

        private void SignInButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new SignInPage());
          
        }

        private void SubmitButton_Clicked(object sender, EventArgs e)
        {
            string[] entriesArray = new string[5];
            entriesArray[0] = firstNameEntry.Text;
            entriesArray[1] = lastNameEntry.Text;
            entriesArray[2] = emailEntry.Text;
            entriesArray[3] = passwordEntry.Text;
            entriesArray[4] = confirmPasswordEntry.Text;
            bool addUser = ValidateEntries(entriesArray);

            //validate entries
            if (addUser)
            {
                var filename = Path.Combine(App.FolderPath, $"{emailEntry.Text.ToLower()}.WaitTimes.txt");


                if (File.Exists(filename))
                {
                    DisplayAlert("Email Already Exists!", "This email address is associated with another profile. Try signing in below.", "Ok");
                    emailEntry.Text = null;

                }
                else if (passwordEntry.Text != confirmPasswordEntry.Text)
                {
                    DisplayAlert("Password Not Confirmed!", "Passwords do not match. Try Again", "Ok");
                    passwordEntry.Text = null;
                    confirmPasswordEntry.Text = null;

                }
                else
                {


                    newUser.Firstname = firstNameEntry.Text;
                    newUser.Lastname = lastNameEntry.Text;
                    newUser.Email = emailEntry.Text;
                    newUser.Password = passwordEntry.Text;
                    newUser.FavoriteRestaurants = new List<RestaurantData>();
                    var newFilename = Path.Combine(App.FolderPath, $"{newUser.Email.ToLower()}.WaitTimes.txt");

                    //set filename
                    newUser.FileName = newFilename;

                    //write to file
                    using (StreamWriter writer = new StreamWriter(filename))
                    {
                        writer.WriteLine(firstNameEntry.Text);
                        writer.WriteLine(lastNameEntry.Text);
                        writer.WriteLine(emailEntry.Text);
                        writer.WriteLine(passwordEntry.Text);

                    }

                    DisplayAlert("Success!", "Your profile has been created", "Let's Get Started");
                    Navigation.PushAsync(new MainPage());
                    MessagingCenter.Send<UserProfileData>(newUser, "ViewProfile");
                    MessagingCenter.Send<UserProfileData>(newUser, "UserSearch");
                }
            }

            
        }

            private bool ValidateEntries(string[] entries)
        {
            bool valid = true;
            if (valid)
            {
                if (entries.Length >= 0)
                {

                    for (int i = 0; i < 5; i++)
                    {
                        if (string.IsNullOrWhiteSpace(entries[i]))
                        {
                            DisplayAlert("Blank Entry!", "Please don't leave any fields blank", "Ok");
                            firstNameEntry.Text = null;
                            lastNameEntry.Text = null;
                            emailEntry.Text = null;
                            passwordEntry.Text = null;
                            confirmPasswordEntry.Text = null;
                            valid = false;
                        }
                    }
                }
            }
            
            return valid;
        }
    }

    
}
