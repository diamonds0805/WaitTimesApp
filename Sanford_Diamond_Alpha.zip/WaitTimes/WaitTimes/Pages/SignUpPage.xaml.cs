﻿using System;
using System.Collections.Generic;
using System.IO;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SignUpPage : ContentPage
    {
        UserProfileData newUser = new UserProfileData();
        public SignUpPage()
        {
            InitializeComponent();
            submitButton.Clicked += SubmitButton_Clicked;
            signInButton.Clicked += SignInButton_Clicked;
        }

        private void SignInButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new SignInPage());
        }

        private void SubmitButton_Clicked(object sender, EventArgs e)
        {
            string[] entriesArray = new string[5];
            entriesArray[0] = firstNameEntry.Text;
            entriesArray[1] = lastNameEntry.Text;
            entriesArray[2] = emailEntry.Text;
            entriesArray[3] = passwordEntry.Text;
            entriesArray[4] = confirmPasswordEntry.Text;
            bool addUser = ValidateEntries(entriesArray);
            if (addUser)
            {
                var filename = Path.Combine(App.FolderPath, $"{Path.GetRandomFileName()}.WaitTimes.txt");

                //set filename
                newUser.FileName = filename;

                //write to file
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(firstNameEntry.Text);
                    writer.WriteLine(lastNameEntry.Text);
                    writer.WriteLine(emailEntry.Text);
                    writer.WriteLine(passwordEntry.Text);

                }
                newUser.Firstname = firstNameEntry.Text;
                newUser.Lastname = lastNameEntry.Text;
                newUser.Email = emailEntry.Text;
                newUser.Password = passwordEntry.Text;
                DisplayAlert("Success!", "Your profile has been created", "Let's Get Started");
                Navigation.PushAsync(new MainPage());
                MessagingCenter.Send<UserProfileData>(newUser, "ViewFavorites");
                MessagingCenter.Send<UserProfileData>(newUser, "UserSearch");


            }
        }

            private bool ValidateEntries(string[] entries)
        {
            bool valid = true;
            if (entries.Length >= 0)
            {
                for (int i = 0; i < 5; i++)
                {
                    if (string.IsNullOrWhiteSpace(entries[i]))
                    {
                        DisplayAlert("Blank Entry!", "Please don't leave any fields blank", "Ok");
                        firstNameEntry.Text = null;
                        lastNameEntry.Text = null;
                        emailEntry.Text = null;
                        passwordEntry.Text = null;
                        confirmPasswordEntry.Text = null;
                        valid = false;
                    }
                }
            }
            else
            {
                var files = Directory.EnumerateFiles(App.FolderPath, "*.WaitTimes.txt");

                foreach (var filename in files)
                {
                    if (filename != null)
                    {
                        using (StreamReader reader = new StreamReader(filename))
                        {
                            UserProfileData userProfile = new UserProfileData();
                            reader.ReadLine();
                            reader.ReadLine();
                            userProfile.Email = reader.ReadLine();
                            if (entries[2].ToLower() == userProfile.Email)
                            {
                                DisplayAlert("Email Already Exists!", "This email address is associated with another profile. Try signing in below.", "Ok");
                                emailEntry.Text = null;
                                valid = false;
                            }
                        }
                    }
                };
            }

            if (entries[3] != entries[4])
            {
                DisplayAlert("Password Not Confirmed!", "Passwords do not match. Try Again", "Ok");
                passwordEntry.Text = null;
                confirmPasswordEntry.Text = null;
                valid = false;
            }

            return valid;
        }
    }

    
}
