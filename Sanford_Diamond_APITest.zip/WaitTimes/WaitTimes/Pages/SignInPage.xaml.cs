﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SignInPage : ContentPage
    {
        public SignInPage()
        {
            InitializeComponent();
        }
    }
}
