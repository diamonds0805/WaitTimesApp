﻿using System;
using System.Collections.Generic;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class RestaurantDetails_FromProfile : ContentPage
    {
        RestaurantData favorite = new RestaurantData();
        UserProfileData currentUser = new UserProfileData();

        public RestaurantDetails_FromProfile()
        {
            InitializeComponent();
            MessagingCenter.Subscribe<RestaurantData>(this, "SeeDetails_Profile", (sender) =>
             {
                 favorite = sender;
                 nameLabel.Text = favorite.RestaurantName;
                 

             });
            MessagingCenter.Subscribe<UserProfileData>(this, "SeeDetails_User", (sender) =>
            {
                currentUser = sender;

            });

            closeButton.Clicked += CloseButton_Clicked;
            seeCurrentWait.Clicked += SeeCurrentWait_Clicked;
            hoursButton.Clicked += HoursButton_Clicked;

        }

        private void SeeCurrentWait_Clicked(object sender, EventArgs e)
        {
            detailsLabel.IsVisible = true;
            detailsFrame.IsVisible = true;
            detailsLabel.Text = favorite.CurrentWait;
        }

        private void HoursButton_Clicked(object sender, EventArgs e)
        {
            detailsLabel.IsVisible = true;
            detailsFrame.IsVisible = true;
            if (string.IsNullOrWhiteSpace(favorite.BusinessHours))
            {
                DisplayAlert("No Hours", "Business Hours Not Found!", "Ok");
            }
            else
            {
                detailsLabel.Text = favorite.BusinessHours;
            }
        }

        /*private async void DeleteFromFavoritesButton_ClickedAsync(object sender, EventArgs e)
        {
            bool delete = await DisplayAlert("Delete Favorites", $"Are you sure you want to delete {favorite.RestaurantName} from your favorites?", "Yes", "No");
            if (delete)
            {
                foreach(RestaurantData restaurant in currentUser.FavoriteRestaurants)
                {
                    if(favorite.RestaurantName == restaurant.RestaurantName)
                    {
                        currentUser.FavoriteRestaurants.Remove(restaurant);
                        await DisplayAlert("Removed!", $"{favorite.RestaurantName} has been deleted from your favorites", "Ok");
                        await Navigation.PopModalAsync();
                    }
                }
            }
            MessagingCenter.Send<UserProfileData>(currentUser, "ViewProfile");
        }*/

        private void CloseButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PopModalAsync();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            detailsLabel.IsVisible = false;
            detailsFrame.IsVisible = false;
        }
    }
}
