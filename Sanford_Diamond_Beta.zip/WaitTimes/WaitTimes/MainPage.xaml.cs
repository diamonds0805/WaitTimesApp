﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using WaitTimes.ViewModels;
using Xamarin.Forms;
using WaitTimes.Pages;

namespace WaitTimes
{
    public partial class MainPage : TabbedPage
    {
        public MainPage()
        {
            InitializeComponent();
            //add tabs for search page and user profile
            SearchPage searchTab = new SearchPage();
            searchTab.Title = "Search";
            searchTab.BackgroundColor = Color.FromHex("#E24C54");
            
            Children.Add(searchTab);

            UserProfile profileTab = new UserProfile();
            profileTab.Title = "Profile";
            profileTab.BackgroundColor = Color.FromHex("#E24C54");
            Children.Add(profileTab);
        }
    }
}
