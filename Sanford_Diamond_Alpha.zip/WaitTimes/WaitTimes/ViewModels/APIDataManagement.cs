﻿using System;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace WaitTimes.ViewModels
{
    public class APIDataManagement
    {
        //set up API connection
         WebClient apiConnection = new WebClient();
         //string startAPI = "https://api.documenu.com/v2/restaurants/zip_code/";
         
        
        public APIDataManagement()
        {
            
        }


        //create function to get api data
        public async Task<List<RestaurantData>> GetRestaurants(string location)
        {
            string apiEndPoint = "https://api.documenu.com/v2/restaurants/zip_code/" + location + "?key=8d74de8c60e7b4edd9d2d98e8d4b71cc";
            string apiString = await apiConnection.DownloadStringTaskAsync(apiEndPoint);
             
            //parse JSON data
            JObject jsonData = JObject.Parse(apiString);

            //create RestaurantData list
            List<RestaurantData> restaurants = new List<RestaurantData>();

            //loop through JSON data and add to list
            foreach(JObject result in jsonData["data"])
            {
                RestaurantData restaurant = new RestaurantData();
                restaurant.BusinessID = result["restaurant_id"].ToString();
                restaurant.RestaurantName = result["restaurant_name"].ToString() ;
                //restaurant.CuisineType = result["cuisines[0]"].ToString();
                restaurant.BusinessHours = result["hours"].ToString();
                //string[] addressArr = result["address"].T
                //restaurant.BusinessAddress = ;
                //restaurant.Logo = ImageSource.FromUri(new Uri( result["image_url"].ToString()));
                restaurants.Add(restaurant);
            }

            //return list
            return restaurants;
        }

        public async Task<RestaurantData> GetFavoriteRestaurantsAsync(string ID)
        {
            
            
                string apiEndPoint = "https://api.documenu.com/v2/restaurant/" + ID + "?key=8d74de8c60e7b4edd9d2d98e8d4b71cc";
                string apiStr = await apiConnection.DownloadStringTaskAsync(apiEndPoint); 

                JObject data = JObject.Parse(apiStr);
                    RestaurantData restaurant = new RestaurantData();
                    restaurant.BusinessID = ID;
                    restaurant.RestaurantName = data["restaurant_name"].ToString();
                    restaurant.BusinessHours = data["hours"].ToString();
            
            return restaurant;
        }
    }
}
