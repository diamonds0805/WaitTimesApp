﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace WaitTimes.ViewModels
{
    public class RestaurantData
    {
        //properties for restaurant information
        public string BusinessID { get; set; }
        public string RestaurantName { get; set; }
        //public string CuisineType { get; set; }
        public string BusinessHours { get; set; }
        public string BusinessAddress { get; set; }
        //public ImageSource Logo { get; set; }
        //function to calculate current wait time
        public static string CalcCurrentWait()
        {
            double numOfCurrCustomers = 20;
            double minPerCustomer = 10;
            double totalMins = numOfCurrCustomers * minPerCustomer;

            return totalMins + "minute wait";
        }

        
    }
}
