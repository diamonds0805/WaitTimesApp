﻿using System;
using System.Collections.Generic;
using WaitTimes.ViewModels;
using Xamarin.Forms;

namespace WaitTimes.Pages
{
    public partial class SearchPage : ContentPage
    {
        //create list for listview datatemplate
        List<RestaurantData> restaurants = new List<RestaurantData>();

        public SearchPage()
        {
            InitializeComponent();
            //set up dataTemplate
            DataTemplate restaurantData = new DataTemplate(typeof(ImageCell));
            restaurantData.SetBinding(ImageCell.ImageSourceProperty, new Binding("Logo"));
            restaurantData.SetBinding(ImageCell.TextProperty, new Binding("RestaurantName"));
            restaurantData.SetBinding(ImageCell.DetailProperty, new Binding("BusinessHours"));

            //set listview to dataTemplate
            searchListView.ItemTemplate = restaurantData;

            //create searchBar event
            searchBar.TextChanged += SearchBar_TextChanged;
            
        }

        async void SearchBar_TextChanged(object sender, TextChangedEventArgs e)
        {
            //Validation.ValNotEmpty(searchBar.Text);
            //use try catch to search API
            if (!string.IsNullOrWhiteSpace(searchBar.Text))
            {
                restaurants.Clear();
                try
                {
                    SearchBar searchBar = (SearchBar)sender;
                    APIDataManagement aPIData = new APIDataManagement(searchBar.Text);
                    searchListView.ItemsSource = await aPIData.GetRestaurants();
                }
                catch
                {

                    searchBar.Text = null;
                    searchBar.Placeholder = "Enter Zipcode";
                    await DisplayAlert("No Restaurants Found!", "Try another zip code.", "Ok");
                }
            }

        }
    }
}
